﻿/*
 * Created by Ranorex
 * User: FAF
 * Date: 22/6/2022
 * Time: 10:43 a. m.
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using System.IO;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace TRP.JDE
{
	/// <summary>
	/// Description of verificarEstadoTC.
	/// </summary>
	[TestModule("C7EA0E3C-39DC-40D6-BF9C-F824A4CF0DD2", ModuleType.UserCode, 1)]
	public class verificarEstadoTC : ITestModule
	{
		/// <summary>
		/// Constructs a new instance.
		/// </summary>
		public verificarEstadoTC()
		{
			// Do not delete - a parameterless constructor is required!
		}

		string _path = "";
		[TestVariable("ab924994-2d14-4c5a-89f7-42a97a1dc52c")]
		public string path
		{
			get { return _path; }
			set { _path = value; }
		}

		/// <summary>
		/// Performs the playback of actions in this module.
		/// </summary>
		/// <remarks>You should not call this method directly, instead pass the module
		/// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
		/// that will in turn invoke this method.</remarks>
		void ITestModule.Run()
		{
			Mouse.DefaultMoveTime = 300;
			Keyboard.DefaultKeyPressTime = 100;
			Delay.SpeedFactor = 1.0;
			
			var result = TestSuite.CurrentTestContainer.Status;
			Report.Log(ReportLevel.Info, result.ToString());
			
			if(result.ToString()=="Failed")
			{
				//string path = @"C:\TEMP\valorDolar.txt";
				try {
					File.Delete(path);
					Report.Success("Info","Archivo "+path+" eliminado correctamente");
				} catch(Exception e) {
					Report.Failure("Fail", "Error al eliminar el archivo\r\nError: " + e);
					throw;
				}
			}
		}
	}
}
