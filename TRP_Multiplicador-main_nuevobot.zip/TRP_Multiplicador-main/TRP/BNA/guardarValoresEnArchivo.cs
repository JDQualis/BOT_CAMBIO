﻿/*
 * Created by Ranorex
 * User: Irina Storozuk
 * Date: 17/05/2022
 * Time: 10:15 a. m.
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace TRP.BNA
{
	/// <summary>
	/// Description of guardarValoresEnArchivo.
	/// </summary>
	[TestModule("7334FCDE-5D07-491E-957E-D5F8D5855553", ModuleType.UserCode, 1)]
	public class guardarValoresEnArchivo : ITestModule
	{
		/// <summary>
		/// Constructs a new instance.
		/// </summary>
		public guardarValoresEnArchivo()
		{
			// Do not delete - a parameterless constructor is required!
		}

		string _DolarBilleteVariable = "";
		[TestVariable("6f285f60-3b0c-4b6a-bbd1-451561062422")]
		public string DolarBilleteVariable
		{
			get { return _DolarBilleteVariable; }
			set { _DolarBilleteVariable = value; }
		}

		string _pathArchivo = "";
		[TestVariable("3b1f63f5-f8b7-4a31-9744-78f00f1045b9")]
		public string pathArchivo
		{
			get { return _pathArchivo; }
			set { _pathArchivo = value; }
		}

		string _DolarDivisaVariable = "";
		[TestVariable("d07955fa-22fa-4680-abeb-44592df34bb3")]
		public string DolarDivisaVariable
		{
			get { return _DolarDivisaVariable; }
			set { _DolarDivisaVariable = value; }
		}

		/// <summary>
		/// Performs the playback of actions in this module.
		/// </summary>
		/// <remarks>You should not call this method directly, instead pass the module
		/// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
		/// that will in turn invoke this method.</remarks>
		void ITestModule.Run()
		{
			Mouse.DefaultMoveTime = 300;
			Keyboard.DefaultKeyPressTime = 100;
			Delay.SpeedFactor = 1.0;
			
			//verificarDirectorio();
			//string path = @"C:\TEMP\valorDolar.txt";
			bool exist = File.Exists(_pathArchivo);
			
			
			if(exist) {
				try {
					File.WriteAllText(_pathArchivo,"Billete:" + DolarBilleteVariable);
					//File.AppendAllText(path,"Divisa:"+DolarDivisaVariable);
					Report.Info("Info", "El archivo "+_pathArchivo+" ya existía previamente");
					Report.Success("Info", "Los datos han sido guardados correctamente");
				} catch (Exception e) {
					Report.Failure("Fail", "Error al guardar los datos\r\nError: " + e);
					throw;
				}
			}	else {
				try {
					Report.Info("Info", "Se creó el archivo: "+_pathArchivo);
					File.WriteAllText(_pathArchivo,"Billete:" + DolarBilleteVariable);
					//File.AppendAllText(path,"Divisa:"+DolarDivisaVariable);
					Report.Success("Info", "Los datos han sido guardados correctamente");
				} catch (Exception e) {
					Report.Failure("Fail", "Error al crear el archivo o guardar los datos\r\nError: " + e);
					throw;
				}
			}
		}
	}
}


