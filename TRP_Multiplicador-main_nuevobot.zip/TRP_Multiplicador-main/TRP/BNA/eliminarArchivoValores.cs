﻿/*
 * Created by Ranorex
 * User: Irina Storozuk
 * Date: 17/05/2022
 * Time: 11:52 a. m.
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace TRP.BNA
{
	/// <summary>
	/// Description of eliminarArchivoValores.
	/// </summary>
	[TestModule("B809E04B-ABAB-4488-A244-5B184471225F", ModuleType.UserCode, 1)]
	public class eliminarArchivoValores : ITestModule
	{
		/// <summary>
		/// Constructs a new instance.
		/// </summary>
		public eliminarArchivoValores()
		{
			// Do not delete - a parameterless constructor is required!
		}

		string _path = "";
		[TestVariable("b8f60eb0-e98c-4d88-b210-c0ab53f93700")]
		public string path
		{
			get { return _path; }
			set { _path = value; }
		}

		/// <summary>
		/// Performs the playback of actions in this module.
		/// </summary>
		/// <remarks>You should not call this method directly, instead pass the module
		/// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
		/// that will in turn invoke this method.</remarks>
		void ITestModule.Run()
		{
			Mouse.DefaultMoveTime = 300;
			Keyboard.DefaultKeyPressTime = 100;
			Delay.SpeedFactor = 1.0;
			
			
			//string path = @"C:\TEMP\valorDolar.txt";
			try{
				File.Delete(path);
				Report.Success("Info","Archivo valorDolar.txt eliminado correctamente");
			}
			catch(Exception e) {
				Report.Failure("Fail", "Error al eliminar el archivo\r\nError: " + e);
				throw;
			}
		}
	}
}
