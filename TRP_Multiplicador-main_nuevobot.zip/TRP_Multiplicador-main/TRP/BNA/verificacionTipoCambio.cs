﻿/*
 * Created by Ranorex
 * User: Irina Storozuk
 * Date: 17/05/2022
 * Time: 10:27 a. m.
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace TRP.BNA
{
	/// <summary>
	/// Description of verificacionTipoCambio.
	/// </summary>
	[TestModule("D5AE6AA7-ABAB-4651-9D16-6E83E255A326", ModuleType.UserCode, 1)]
	public class verificacionTipoCambio : ITestModule
	{
		/// <summary>
		/// Constructs a new instance.
		/// </summary>
		public verificacionTipoCambio()
		{
			// Do not delete - a parameterless constructor is required!
		}

		string _path = "";
		[TestVariable("01c50a53-ef16-49e7-a8a2-fe21b9d749f0")]
		public string path
		{
			get { return _path; }
			set { _path = value; }
		}

		string _DolarDivisaVariable = "";
		[TestVariable("9b2d74d0-d8a3-41d6-93ca-d10f84842149")]
		public string DolarDivisaVariable
		{
			get { return _DolarDivisaVariable; }
			set { _DolarDivisaVariable = value; }
		}

		string _DolarBilleteVariable = "";
		[TestVariable("f8377c16-aeb3-4ff0-b374-e72ddf591c8e")]
		public string DolarBilleteVariable
		{
			get { return _DolarBilleteVariable; }
			set { _DolarBilleteVariable = value; }
		}

		/// <summary>
		/// Performs the playback of actions in this module.
		/// </summary>
		/// <remarks>You should not call this method directly, instead pass the module
		/// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
		/// that will in turn invoke this method.</remarks>
		void ITestModule.Run()
		{
			Mouse.DefaultMoveTime = 300;
			Keyboard.DefaultKeyPressTime = 100;
			Delay.SpeedFactor = 1.0;
			
			//string path = @"C:\TEMP\valorDolar.txt";
			bool exist = File.Exists(path);
			int counter=0;
			bool findBillete = false;
//			bool findDivisa = false;
			
			Report.Info("Info", "Iniciando verificación del tipo de cambio cargado vs. el tipo de cambio actual");
			
			
			if(exist) {
				foreach (string line in System.IO.File.ReadLines(path))
				{
					Report.Info("Info", line);
					counter++;
					
					if(line.Contains("Billete")) {
						if(DolarBilleteVariable.Equals(line.Split(':')[1])) {
							Report.Info("Info", "Valor billete coincide");
							findBillete=true;
						} else {
							DolarBilleteVariable=line.Split(':')[1];
							Report.Info("Info", "Se actualiza el dolar billete porque no coincide con el cargado");
						}
					}
					
//					if(line.Contains("Divisa")){
//						if(DolarDivisaVariable.Equals(line.Split(':')[1])) {
//							Report.Info("Info", "Valor divisa coincide");
//							findDivisa=true;
//						} else {
//							DolarDivisaVariable=line.Split(':')[1];
//							Report.Info("Info", "Se actualiza el dolar divisa porque no coincide con el cargado");
//						}
//					}
				}
				
				Report.Info("ESTADO BILLETE: ", findBillete.ToString());
//				Report.Info("ESTADO DIVISA: ", findBillete.ToString());
				
				if(!findBillete) { // || !findDivisa) {
					TestSuite.Current.Parameters["ejecutarEdicion"]="S";
					Report.Info("Info", "Se debe ejecutar la edición de la carga nuevamente");
				} else {
					Report.Info("Info", "Los tipos de cambio coinciden. No se debe ejecutar la edicion de la carga");
				}
			} else {
				//Report.Info("Info", @"El archivo C:\TEMP\valorDolar.txt no existe. No se realizó la carga anteriormente");
				Report.Info("Info", @"El archivo "+path+" no existe. No se realizó la carga anteriormente");
				TestSuite.Current.Parameters["ejecutarCarga"]="S";
				//Guardar los valores actuales ¿?
			}
		}
	}
}
