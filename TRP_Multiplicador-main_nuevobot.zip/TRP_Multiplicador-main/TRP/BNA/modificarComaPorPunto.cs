﻿/*
 * Created by Ranorex
 * User: Irina Storozuk
 * Date: 03/05/2022
 * Time: 10:51 a. m.
 * 
 * To change this template use Tools > Options > Coding > Edit standard headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace TRP
{
    /// <summary>
    /// Description of modificarComaPorPunto.
    /// </summary>
    [TestModule("5A5B016F-7E7A-43C5-81FB-5E0A07D7664A", ModuleType.UserCode, 1)]
    public class modificarComaPorPunto : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public modificarComaPorPunto()
        {
            // Do not delete - a parameterless constructor is required!
        }
        
        
        string _DolarBilleteVariable = "";
        [TestVariable("c83bb2d8-bcf1-4550-9b76-44e1733d0a7b")]
        public string DolarBilleteVariable
        {
        	get { return _DolarBilleteVariable; }
        	set { _DolarBilleteVariable = value; }
        }
        
        string _DolarDivisaVariable = "";
        [TestVariable("f44f6879-d3d4-4039-8ba7-7a43464944ce")]
        public string DolarDivisaVariable
        {
        	get { return _DolarDivisaVariable; }
        	set { _DolarDivisaVariable = value; }
        }
        

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {       	
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
            
            DolarBilleteVariable=DolarBilleteVariable.Replace(',','.');
            DolarDivisaVariable=DolarDivisaVariable.Replace(',','.');

        }
    }
}
